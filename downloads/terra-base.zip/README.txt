﻿Codex Studio - Free Asset placeholder archive

Asset: terra-base
License: CC0 1.0 (public domain)

PLACEHOLDER archive. The real model package (Blender / FBX / GLB + textures)
will replace it; Download is wired and working. Owner swaps the real file in later.

https://codex.promo/free-assets.html
